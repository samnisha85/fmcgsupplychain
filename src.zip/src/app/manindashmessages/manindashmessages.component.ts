import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manindashmessages',
  templateUrl: './manindashmessages.component.html',
  styleUrls: ['./manindashmessages.component.scss']
})
export class ManindashmessagesComponent implements OnInit {
  sidebarExpanded = true;

  constructor() { }

  ngOnInit(): void {
  }

}
