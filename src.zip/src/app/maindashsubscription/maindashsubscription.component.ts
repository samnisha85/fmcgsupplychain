import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-maindashsubscription',
  templateUrl: './maindashsubscription.component.html',
  styleUrls: ['./maindashsubscription.component.scss']
})
export class MaindashsubscriptionComponent implements OnInit {
  sidebarExpanded = true;

  constructor() { }

  ngOnInit(): void {
  }

}
