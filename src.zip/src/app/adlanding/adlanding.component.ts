import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adlanding',
  templateUrl: './adlanding.component.html',
  styleUrls: ['./adlanding.component.scss']
})
export class AdlandingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
