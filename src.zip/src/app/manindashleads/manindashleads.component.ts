import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manindashleads',
  templateUrl: './manindashleads.component.html',
  styleUrls: ['./manindashleads.component.scss']
})
export class ManindashleadsComponent implements OnInit {
  sidebarExpanded = true;

  constructor() { }

  ngOnInit(): void {
  }

}
