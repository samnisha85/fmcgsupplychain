const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');

const app = express();
const port = 3000;

// const db = mysql.createConnection({
//   host: 'your-database-host',
//   user: 'your-database-username',
//   password: 'your-database-password',
//   database: 'your-database-name',
// });

const db = mysql.createConnection({
    host: '162.241.252.224',
    user: 'mijohhmy',
    password: 'Pass,1234',
    database: 'mijohhmy_phytolabcommunity'
  });

app.use(bodyParser.json());

// app.post('/api/saveUser', (req, res) => {
//   const userData = req.body;

  // Implement MySQL query to save user data
  // Handle errors and send a response back
 
// });

app.post('/api/saveUser', (req, res) => {
    // const { eventName, eventDate,eventStreet,  eventCity, eventZipcode,eventState, eventCountry, eventSchedule,eventImage } = req.body;
    // console.log(req.body);
    // const userType = "free";
    const userData = req.body;   
    console.log(userData.name); 

    // Insert the event details into the database
    const sql = 'INSERT INTO create_event_free (event_name ) VALUES (?)';
    db.query(sql, [userData.name], (err, result) => {
        if (err) {
            console.error('Error inserting event:', err);
            return res.render('subscribe', {
                message: 'Subscription failed. Please try again later.',
                messageClass: 'error',
            });
        }

        console.log('Event inserted into the database');

        // Display a success message
        // res.render('subscribe', {
        //     message: 'Thank you for subscribing!',
        //     messageClass: 'success',
        // });
        // res.render('event_submitted',{message:null, messageClass:''});
    });
});







app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});